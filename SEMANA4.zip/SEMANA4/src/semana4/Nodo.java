/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package semana4;

/**
 *
 * @author o12302
 */
public class Nodo {
    int clave; // Dato almacenado
    Nodo siguiente; // Referencia al siguiente nodo
    
    // Constructor
    public Nodo(int clave) {
        this.clave = clave;
        this.siguiente = null;
}
}
